﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Musicalog.Services;
using System.Configuration;

namespace Musicalog.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewBag.Message = "Album Catalog";
            AlbumBO albumbo = new AlbumBO();
            albumbo.getAllAlbum();
            ViewBag.allAlbum = albumbo.getAllAlbum();
            ViewBag.pagecount = ConfigurationManager.AppSettings["StartingMonthColumn"];

            return View();
        }

        [HttpGet]
        public ActionResult CreateAlbum()
        {
            var album = new MasterAlbum();
            return View();
        }

        [HttpPost]
        public ActionResult CreateAlbum(MasterAlbum malbum)
        {
            AlbumBO albumbo = new AlbumBO();
            albumbo.AddAlbum(malbum);
            return View();
        }

        public ActionResult EditAlbum(int albumId)
        {
            AlbumBO albumbo = new AlbumBO();
            ViewBag.title = "Edit Album";
          //  ViewBag.Album = albumbo.getAlbumByID(albumId);
            return View("CreateAlbum", albumbo.getAlbumByID(albumId));
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}
