﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Musicalog.Services
{
    public class MasterAlbum
    {
        public int Albumid;
        public string AlbumName;
        public string Artist;
        public int Stock;
        public MetaAlbumType albumType;
        public MasterAlbum(int aid, string aname, string artist, int stock, MetaAlbumType mt)
        {
            Albumid = aid;
            AlbumName = aname;
            Artist = artist;
            Stock = stock;
            albumType = mt;
        }

        public MasterAlbum() { }
    }
    public class MetaAlbumType
    {
        public int TypeID;
        public string Code;
        public string Desc;
        public MetaAlbumType() { }
        public MetaAlbumType(int typeid, string code, string desc) {
            TypeID = typeid;
            Code = code;
            Desc = desc;
        }

    }

    public class AlbumEO
    {
        List<MasterAlbum> MasterAlbums = new List<MasterAlbum>();


    }

}