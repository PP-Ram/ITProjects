﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Musicalog.Services
{
    public class AlbumBO
    {
        public List<MasterAlbum> lstAlbums;
        
        public List<MasterAlbum> getAllAlbum()
        {
            lstAlbums = new List<MasterAlbum>(); ;
            MetaAlbumType mt1 = new MetaAlbumType(1, "CD", "Compact Disc");
            MetaAlbumType mt2 = new MetaAlbumType(2, "VINYL", "Vinyl");
            
            MasterAlbum tempalbum ;

            tempalbum = new MasterAlbum(1, "TestAlbum1", "Artist1", 15, mt1);
            lstAlbums.Add(tempalbum);
            tempalbum = new MasterAlbum(2, "TestAlbum2", "Artist2", 20, mt2);
            lstAlbums.Add(tempalbum);
            tempalbum = new MasterAlbum(3, "TestAlbum3", "Artist3", 27, mt1);
            lstAlbums.Add(tempalbum);


            return lstAlbums;
        }

        public MasterAlbum getAlbumByID(int Albumid)
        {
            return getAllAlbum().Find(t => t.Albumid == Albumid);
        }

        public bool AddAlbum(MasterAlbum newAlbu)
        {
            //Find if exists or NOT WCF
            //return getAllAlbum().Find(t => t.Albumid == Albumid);
            return true;
        }

        public bool UpdateAlbum(MasterAlbum updateAlbum)
        {
            //return getAllAlbum().Find(t => t.Albumid == Albumid);
            return true;
        }

        public bool RemoveAlbum(int albumId)
        {
            //return getAllAlbum().Find(t => t.Albumid == Albumid);
            return true;
        }

    }

    public class DataBaseAlbumBO
    {
    }
}